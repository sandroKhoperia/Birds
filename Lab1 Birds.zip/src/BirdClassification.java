/**
 * Classification of the birds
 */
public enum BirdClassification {
    BIRD_OF_PREY,
    FLIGHTLESS,
    OWL,
    PARROT,
    SHOREBIRD,
    WATERFOWL,
    PIGEON,
}
