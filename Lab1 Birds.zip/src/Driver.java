public class Driver {
    public static void main(String[] args) throws Exception {
        var parrot = new Parrot(BirdType.GRAYPARROT, "CS5010", null);
        parrot.teachParrotAWord("Programming");
        parrot.teachParrotAWord("Coding");
        parrot.teachParrotAWord("Java");

        var owl1 = new Owl(BirdType.OWL);
        var owl2 = new Owl(BirdType.OWL);
        var owl3 = new Owl(BirdType.OWL);
        var owl4 = new Owl(BirdType.OWL);
        var owl5 = new Owl(BirdType.OWL);


        var eagle = new BirdOfPrey(BirdType.EAGLE);
        var kiwi = new FlightlessBird(BirdType.KIWI);
        var goose = new Waterfowl(BirdType.GOOSE);

        var conservatory =  new Conservatory();
        conservatory.rescueBird(parrot);
        conservatory.rescueBird(owl1);
        conservatory.rescueBird(owl2);
        conservatory.rescueBird(owl3);
        conservatory.rescueBird(owl4);
        conservatory.rescueBird(owl5);
        conservatory.rescueBird(eagle);
        conservatory.rescueBird(kiwi);
        conservatory.rescueBird(goose);

        var gooseAviary = conservatory.searchAviaryByBird(goose);
        System.out.println(String.format("Goose is in Aviary with id: %s ", gooseAviary));
        System.out.println();

        System.out.println("All birds in sorted order with their respective aviary ids:");
        conservatory.printSortedBirds();
        System.out.println();
        System.out.println();


        System.out.println("Food Storage contents:");
        conservatory.listFoodStorageContents();
        System.out.println();
        System.out.println();

        System.out.println("All aviaries with the birds they house:");
        conservatory.listAllAviaries();
    }
}
