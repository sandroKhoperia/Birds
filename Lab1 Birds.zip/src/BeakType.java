/**
 * Represents type of the beak values
 */
public enum BeakType {
    HOOKED,
    CURVED
}
