/**
 * Represents different sizes of beak
 */
public enum BeakSize {
    SHORT,
    LONG
}

