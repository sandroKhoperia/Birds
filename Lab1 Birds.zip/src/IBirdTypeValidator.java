/**
 * Provide method signature for bird type validation.
 */
public interface IBirdTypeValidator {
    void validateBirdType(BirdType birdType);
}
